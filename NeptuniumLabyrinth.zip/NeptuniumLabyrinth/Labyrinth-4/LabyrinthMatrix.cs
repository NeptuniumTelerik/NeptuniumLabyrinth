﻿using System;
using System.Linq;

namespace Labyrinth
{
    public class LabyrinthMatrix
    {
        private readonly Random randomGenerator = new Random();
        private readonly char[] symbols = { '-', 'X' };

        private char[,] matrix;

        public char[,] Matrix
        {
            get
            {
                return this.matrix;
            }
            set
            {
                this.matrix = value;
            }
        }

        public LabyrinthMatrix(int rows, int cols)
        {
            this.Matrix = new char[rows,cols];
            GenerateLabyrinthMatrix();
        }

        private void GenerateLabyrinthMatrix()
        {
            for (int row = 0; row < this.matrix.GetLength(0); row++)
            {
                for (int col = 0; col < this.matrix.GetLength(1); col++)
                {
                    this.matrix[row, col] = GetRandomSymbol();
                }
            }

            int middle = this.matrix.GetLength(0) / 2;
            this.matrix[middle, middle] = '-';
        }

        private char GetRandomSymbol()
        {
            int index = randomGenerator.Next(0, symbols.Length);
            return symbols[index];
        }
    }
}
