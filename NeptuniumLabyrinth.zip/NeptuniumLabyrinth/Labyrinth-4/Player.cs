﻿using System;

namespace Labyrinth
{
    class Player
    {
        public readonly char playerSymbol = '*';

        private LabyrinthMatrix labyrinth;

        private int row;
        private int col;

        public LabyrinthMatrix Labyrinth
        {
            get { return this.labyrinth; }
            set { this.labyrinth = value; }
        }

        public int Row
        {
            get { return this.row; }
            set { this.row = value; }
        }

        public int Col
        {
            get { return this.col; }
            set { this.col = value; }
        }

        public Player(int totalRows, int totalCols)
        {
            this.Row = totalRows/2;
            this.Col = totalCols/2;
            this.Labyrinth = new LabyrinthMatrix(totalRows,totalCols);
        }

        //Player Movement Implementation

        public bool MoveDown()
        {
            if (this.row != 6 && this.labyrinth.Matrix[this.row + 1, this.col] == '-')
            {
                this.row++;
                return true;
            }
            return false;
        }

        public bool MoveUp()
        {
            if (this.row != 0 && this.labyrinth.Matrix[this.row - 1, this.col] == '-')
            {
                this.row--;
                return true;
            }
            return false;
        }

        public bool MoveRight()
        {
            if (this.col != 6 && this.labyrinth.Matrix[this.row, this.col + 1] == '-')
            {
                this.col++;
                return true;
            }
            return false;
        }

        public bool MoveLeft()
        {
            if (this.col != 0 && this.labyrinth.Matrix[this.row, this.col - 1] == '-')
            {
                this.col--;
                return true;
            }
            return false;
        }
    }
}
