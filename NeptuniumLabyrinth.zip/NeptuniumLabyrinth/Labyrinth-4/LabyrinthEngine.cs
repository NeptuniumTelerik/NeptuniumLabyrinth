﻿using System;

namespace Labyrinth
{
    public class LabyrinthEngine
    {

        private TopFiveScoreboard scoreboard;

        private Player player;

        private uint moveCount;

        public LabyrinthEngine()
        {
            this.scoreboard = new TopFiveScoreboard();
        }

        private void Start()
        {
            Console.Clear();
            this.player = new Player(7, 7);
            this.moveCount = 0;

            while (true)
            {
                DrawLabyrinth();
                GameControl();
                Console.Clear();
                if (IsFinished())
                {
                    break;
                }
            }
        }

        public void GameMenuControl()
        {
            Console.WriteLine(Environment.NewLine +
               "Welcome to “Labirinth” game. Please try to escape.\n" +
               "Commands:\n'TOP' to view the top scoreboard\n'START' to start a new game" +
               "\n'EXIT' to quit the game");

            string input = ReadInput();

            switch (input)
            {
                case "top": scoreboard.ShowScoreboard(); break;
                case "start": Start(); break;
                case "exit": Console.WriteLine("Good bye!"); System.Environment.Exit(0); break;
                default: Console.WriteLine("Invalid command!"); break;
            }

        }

        public void GameControl()
        {
            Console.Write("Enter your move (L=left, R-right, U=up, D=down): ");
            string input = ReadInput();
            if (MovePlayer(input))
            {
                this.moveCount++;
            }
            else
            {
                Console.WriteLine("Invalid Move !");
            }
        }

        public string ReadInput()
        {
            string input = Console.ReadLine();
            string lowerInput = input.ToLower();
            return lowerInput;
        }

        public bool MovePlayer(string value)
        {
            switch (value)
            {
                case "l":return this.player.MoveLeft(); 
                case "r":return this.player.MoveRight(); 
                case "u":return this.player.MoveUp(); 
                case "d":return this.player.MoveDown();
                default: return false;
            }
        }

        public void DrawLabyrinth()
        {
            char[,] matrix = player.Labyrinth.Matrix;
            Console.WriteLine();

            for (int row = 0; row < matrix.GetLength(0); row++)
            {
                for (int col = 0; col < matrix.GetLength(1); col++)
                {
                    if (row == this.player.Row && col == this.player.Col)
                    {
                        Console.Write(this.player.playerSymbol);
                    }
                    else
                    {
                        Console.Write(matrix[row, col]);
                    }
                }
                Console.WriteLine();
            }
        }

        private bool IsFinished()
        {
            if (this.player.Row == 0 || this.player.Row == 6 || this.player.Col == 0 || this.player.Col == 6)
            {
                Console.WriteLine("Congratulations! You escaped in " + moveCount + " moves.");
                scoreboard.HandleScoreboard(moveCount);
                return true;
            }

            return false;
        }
    }
}
